// components/wDecBlock/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    content: Object,
    likeStatus: Boolean,
    index: Number,
    chinese: String,
    value: String
  },

  /**
   * 组件的初始数据
   */
  data: {
    likeSrc: './images/star_off.png',
    disLikeSrc: './images/star_on.png',
  },

  /**
   * 组件的方法列表
   */
  methods: {
    onConfirm: function (e) {
      this.triggerEvent('confirm', { userInput: e.detail.value }, {})
    },
    onLike: function () {
      let chinese = this.data.content.chinese
      let likeStatus = this.data.content.likeStatus
      let index = this.data.content.index
      this.setData({
        likeStatus: !likeStatus
      })
      this.triggerEvent('like', {chinese: chinese, likeStatus: likeStatus,index: index}, {})
    }
  }
})
