// components/wordCard/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    imgSrc: String,
    examples: Array
  },

  /**
   * 组件的初始数据
   */
  data: {
    example: '',
    index: 0,
    indexNew: 0
  },

  /**
   * 组件的方法列表
   */
  methods: {
    onSwitch: function (e) {
      let index = this.data.index 
      let examples = this.data.examples
      let indexNew = 0

      indexNew = index == (examples.length) - 1 ? 0 : index + 1
      this.setData({
        index: indexNew
      })
    }
  }
})
