// components/wDeconstructed/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    writingData: Object,
    value: String
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    onConfirm: function (e) {
      let userInputBlock = e.detail.userInput
      let userIndex = e.currentTarget.dataset.index
      this.triggerEvent('decConfirm', { userInputBlock: userInputBlock, userIndex: userIndex}, {})
    },

    onLike: function (e) {
      let chinese = e.detail.chinese
      let likeStatus = e.detail.likeStatus
      let index = e.detail.index
      this.triggerEvent('like', { chinese: chinese, likeStatus: likeStatus, index: index }, {})
    }

  }
})
