// components/lBlock/index.js
Component({
  externalClasses: ['background-style', 'text-style'],
  /**
   * 组件的属性列表
   */
  properties: {
    content: Object,
    chosen: Boolean
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    onChoose: function() {
      let name = this.data.content.name
      let type = this.data.content.type
      this.triggerEvent('choose', { name: name, type: type }, {})
    }
  }
})
