// components/wNormal/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    writingData: Object,
    value: String
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    onConfirm: function (e) {
      this.triggerEvent('norConfirm', { userInput: e.detail.value }, {})
    },

    onLittleHard: function (e) {
      this.triggerEvent('changeState', { state: 'deconstructed'}, {})
    }
  }
})
