
App({
  onLaunch: function () {
    
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        traceUser: true,
      })
    }

    this.globalData = {}

    //清除缓存
    wx.clearStorage()
    
    // 因为不能手动导入数据库，故在此导入一次数据。
    // 之后若需再次导入，去掉注释即可（导入完成后要加上注释！不然会持续导入数据）
    // const db = wx.cloud.database()
    // db.collection('writing').add({
    //   data: {
    //     topicIndex: 0,
    //     writingData_0: {
    //       chinese: "世界正在飞速发展，相应地，人们也在一代一代地进步",
    //       english: "The world is rapidly developing, correspondingly, people are progressing generation after generation.",
    //       chineseBlock: [
    //         {
    //           content: "世界正在飞速发展",
    //           likeStatus: false
    //         },
    //         {
    //           content: "相应地",
    //           likeStatus: false
    //         },
    //         {
    //           content: "世界正在飞速发展，相应地，人们也在一代一代地进步",
    //           likeStatus: false
    //         },
    //       ],
    //     },
    //     writingData_1: {
    //       chinese: "相比于老一代，当下年轻人有更广阔的视野，更丰富的学识，和更大的野心",
    //       english: "Currently, the young people have broader horizen, richer knowledge and greater ambition than the elder generation.",
    //       chineseBlock: [
    //         {
    //           content: "当下年轻人有更广阔的视野",
    //           likeStatus: false
    //         },
    //         {
    //           content: "更丰富的学识",
    //           likeStatus: false
    //         },
    //         {
    //           content: "更大的野心",
    //           likeStatus: false
    //         },
    //         {
    //           content: "相比于老一代",
    //           likeStatus: false
    //         },
    //       ],
    //     }
    //   },
    //   success: res => {
    //     wx.showToast({
    //       title: '新增记录成功',
    //     })
    //     console.log('[数据库] [新增记录] 成功，记录 _id: ', res._id)
    //   },
    //   fail: err => {
    //     wx.showToast({
    //       icon: 'none',
    //       title: '新增记录失败'
    //     })
    //     console.error('[数据库] [新增记录] 失败：', err)
    //   }
    // })

    // const db = wx.cloud.database()
    // db.collection('preview').add({
    //   data: {
    //     id: 5,
    //     bgdImgFileID: "cloud://huangjing1-76f1c3.6875-huangjing1-76f1c3-1257941649/preview-images/bgdImages/bgdImg_6.jpg",
    //     wordCardImgFileID: "cloud://huangjing1-76f1c3.6875-huangjing1-76f1c3-1257941649/preview-images/wordCardImages/wordCardImg_6.jpg",
    //     likeStatus: false,
    //     name: "slow motion",
    //     type: "word"
    //   },
    //   success: res => {
    //     wx.showToast({
    //       title: '新增记录成功',
    //     })
    //     console.log('[数据库] [新增记录] 成功，记录 _id: ', res._id)
    //   },
    //   fail: err => {
    //     wx.showToast({
    //       icon: 'none',
    //       title: '新增记录失败'
    //     })
    //     console.error('[数据库] [新增记录] 失败：', err)
    //   }
    // })


    // const db = wx.cloud.database()
    // db.collection('review').add({
    //   data: {
    //     id: 3,
    //     reviewImgSrc: "cloud://huangjing1-76f1c3.6875-huangjing1-76f1c3-1257941649/review-image/reviewImg_3.jpg",
    //     reviewData: [
    //       {
    //         index: 0,
    //         chinese: "我不认为你知道",
    //         english: "I don't think you know",
    //         likeStatus: false
    //       },
    //       {
    //         index: 1,
    //         chinese: "青春期是什么？",
    //         english: "what puberty is",
    //         likeStatus: false
    //       }
    //     ],
    //   },
    //   success: res => {
    //     wx.showToast({
    //       title: '新增记录成功',
    //     })
    //     console.log('[数据库] [新增记录] 成功，记录 _id: ', res._id)
    //   },
    //   fail: err => {
    //     wx.showToast({
    //       icon: 'none',
    //       title: '新增记录失败'
    //     })
    //     console.error('[数据库] [新增记录] 失败：', err)
    //   }
    // })

  }
})
