//写作起步页面
//*click StartPracticeBtn => Page: WritingPractice
//*click ChangeTopic => Syn Event: changeTopic 

//导入一些必要Models
import { writingTopic } from '../../../defaultData.js'
import { Writing } from '../../../models/writing.js'
import { Cloud } from '../../../models/cloud.js'

const app = getApp()
let writing = new Writing()
let cloud = new Cloud()

Page({

  /**
   * 页面的初始数据
   * currentTopic: 当前的Topic
   * currentIndex: 当前的Index
   */
  data: {
    currentTopic: '',
    currentIndex: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //获取第一个Topic
    let currentTopic = writingTopic[0]
    this.setData({
      currentTopic: currentTopic
    })
  },

  //开始练习处理函数，进入对应Topic的练习页面
  onPractice: function () {
    wx.navigateTo({
      url: `../writingPractice/writingPractice?index=${this.data.currentIndex}`,
    })
  },

  //改变Topic的处理函数
  changeTopic: function () {
    if (this.data.currentIndex == (writingTopic.length - 1)){
      this.setData({
        currentTopic: writingTopic[0],
        currentIndex: 0
      })
    }
    else {
      this.setData({
        currentTopic: writingTopic[this.data.currentIndex+1],
        currentIndex: this.data.currentIndex + 1
      })
    }

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})