//写作练习页面
//Page: WritingPracticeStart topicIndex => *this.data.topicIndex
//*click ChangeTopic => Syn Event: changeTopic 

//导入内部数据WritingTopics
import { writingTopic } from '../../../defaultData.js'
//导入必要的Models
import { Writing } from '../../../models/writing.js'
import { Cloud } from '../../../models/cloud.js'

const app = getApp()
let writing = new Writing()
let cloud = new Cloud()
Page({

  /**
   * 页面的初始数据
   * topiciIndex: 当下文章的topicIndex
   * topic: 当下文章的topic
   * writingDataTotal: 对应topic文章的全部数据
   * writingIndex: 当下文章所处的index
   * writingData: 当前文章所处index对应的数据
   * state: 当前显示状态
   */
  data: {
    topicIndex: 0,
    topic: '',
    writingDataTotal: null,
    writingIndex: 0,
    writingData: null,
    writingArray: [],
    state: 'normal',

    essayID: 0,
    essayIndex: 0,
    essayChinese: [],
    essayEnglish: [],
    essayInput: [],
    userInput: '',
    userInputArray: [],
    writingArray: [],
    state: 'normal',
    ifFinish: false,
    btnText: 'Next',
    value: '',
    senArray: ['mian', 'chang', 'kuan']
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //获取传入的topicIndex，并更新数据
    let topicIndex = parseInt(options.index)
    this.setData({
      topic: writingTopic[topicIndex]
    })

    //获取duiyingtopic的全部data
    //再加载第一句话
    //res: {
    //topicIndex: 0,
    //chinese: ["", "", ""],
    //english: ["", "", ""]
    //chineseBlock: [["", ""], ["", ""], ["", ""]]
    //}
    writing.getWritingFirst()
      .then((res)=>{
        let writingDataTotal = res
        let writingIndex = this.data.writingIndex
        let writingDataStr = `writingData_${writingIndex}`
        let writingData = writingDataTotal[writingDataStr]

        //生成一个writingArrya空数组，用来存放输入
        let writingArray = new Array(writingDataTotal.essayLength)

        this.setData({
          writingDataTotal: writingDataTotal,
          writingData: writingData,
          writingArray: writingArray
        })
        console.log(writingData)
      })
  },

  norConfirm: function (e) {
    let userInput = e.detail.userInput
    this.setData({
      userInput: userInput
    })
    console.log(`正常状态下的完成输入，输入的内容是${userInput}`)
  },

  decConfirm: function (e) {
    let userInputBlock = e.detail.userInputBlock
    let userIndex = e.detail.userIndex
    let userInputArray = this.data.userInputArray

    userInputArray[userIndex] = userInputBlock
    this.setData({
      userInputArray: userInputArray
    })
    console.log(`解构状态下的完成输入，输入的内容是数组为${userInputArray}`)
  },

  onNext: function (e) {
    //判断是否finish
    
    //获取文章长度
    let writingDataTotal = this.data.writingDataTotal
    let essayLength = writingDataTotal.essayLength
    //获取当下index
    let writingIndex = this.data.writingIndex
    //获取当下writingData
    let writingDataStr = `writingData_${writingIndex}`
    let writingData = writingDataTotal[writingDataStr]
    //获取当下的writingArray
    let writingArray = this.data.writingArray

    //判断是否finish  前一个
    if (writingIndex == (essayLength-2)) {
      this.setData({
        btnText: 'Finish'
      })
      console.log('已到文章的倒数第二句话，再进行点击就是最后一句')
    }

    //判断是否为dec模式，如果是，则需拼接数组
    if (this.data.state != 'normal') {
      let userInput = this.data.userInput
      let _userInput = ''
      let userInputArray = this.data.userInputArray
      for (let i=0; i<userInputArray.length; i++) {
        userInput = _userInput + userInputArray[i]
        _userInput = userInput
      }
      this.setData({
        userInput: userInput
      })
      console.log(`如果为拼接数组状态，最终提交的拼接输入为${userInput}`)
    }

    //无论是正常状态还是解构状态，需要提交的userInput即如下
    let userInput = this.data.userInput
    //设置writingArray
    console.log(writingArray)
    console.log(writingIndex)
    writingArray[writingIndex] = userInput
    this.setData({
      writingArray: writingArray
    })

    console.log(`完成了writingArray的提交，当下的writingArray为：${writingArray}`)

    //加载下一个句子的数据
    let writingIndex_next = writingIndex + 1
    let writingDataStr_next = `writingData_${writingIndex_next}`
    writingData = writingDataTotal[writingDataStr_next]
    this.setData({
      writingIndex: writingIndex_next,
      writingData: writingData,
      state: 'normal',
      value: ''
    })
    console.log(`新的writingData数据为`)
    console.log(writingData)

    //等最后一句话的信息都更新完之后才开始进行essay拼接
    if (writingIndex == (essayLength - 1)) {
      this._onFinish()
      console.log('已到文章的最后一句话')
    }
  },

  _onFinish: function () {
    //将writingArray中得到的userInput进行拼接
    let writingArray = this.data.writingArray
    let essay = ''
    let _essay = ''
    for (let i = 0; i < writingArray.length; i++) {
      essay = _essay + writingArray[i]
      _essay = essay
    }
    console.log(`用户最终完成的文章：${essay}`)

    let topicIndex = this.data.topicIndex
    wx.navigateTo({
      url: `../writingFinished/writingFinished?topicIndex=${topicIndex}&essay=${essay}`
    })
  },

  handleLike: function (e) {
    // 获取当前likeStatus状态，并在本地取反
    let topicIndex = this.data.topicIndex
    let writingIndex = this.data.writingIndex
    let writingDataStr = `writingData_${writingIndex}`
    let writingData = this.data.writingData

    let chinese = e.detail.chinese
    let likeStatus = e.detail.likeStatus
    let index = e.detail.index

    console.log("成功在page中获取点赞信息：")
    console.log(`topic:${topicIndex},${writingDataStr}第${index}个中文:${chinese},现有状态为${likeStatus}`)

    //本地直接更新状态
    let _value = `writingData.chineseBlock[${index}].likeStatus`
    this.setData({
      [_value]: !likeStatus
    })
    console.log(`更改之后的writingData数据为：`)
    console.log(writingData)

    //如果现在的状态为false，则说明该操作为点赞
    if (likeStatus == false) {
      //点赞操作的内部处理函数，在数据库两处更新状态
      //1. userLibrary增添集合 2. 对应writingData全部字段
      console.log('onlike')
      let openid = app.globalData.openid
      let collectionName = 'writing'
      let type = 'sentence'
      let name = chinese
      cloud.addLikeSen(openid, collectionName, type, name, topicIndex, writingDataStr, writingData)
    }
    //否则则为取消赞
    else {
      //取消点赞操作的内部处理函数，在数据库两处更新状态
      //1. userLibrary删除集合 2. 对应writingData全部字段
      console.log('offlike')
      let openid = app.globalData.openid
      let collectionName = 'writing'
      let type = 'sentence'
      let name = chinese
      cloud.deleteLikeSen(openid, collectionName, type, name, topicIndex, writingDataStr, writingData)
    }
  },

  changeState: function (e) {
    this.setData({
      state: e.detail.state
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})