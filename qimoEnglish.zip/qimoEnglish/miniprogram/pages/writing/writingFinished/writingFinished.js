//导入内部数据WritingTopics
import { writingTopic, writingChinese, writingEnglish } from '../../../defaultData.js'

Page({

  /**
   * 页面的初始数据
   * topic: 当前topic
   * essay: 当前essay
   */
  data: {
    topic: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //设置topic, essay, 中文原文，和参考翻译
    let topicIndex = parseInt(options.topicIndex)
    let essay = options.essay
    console.log(writingChinese)
    console.log(writingEnglish)
    let sampleChinese = writingChinese[topicIndex]
    let sampleEnglish = writingEnglish[topicIndex]
    this.setData({
      topic: writingTopic[topicIndex],
      essay:essay,
      sampleChinese: sampleChinese,
      sampleEnglish: sampleEnglish
    })


  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})