//蜘蛛侠详情页面
//*click PreviewBtn => Page: SpiderPreview 
//*click ReviewBtn => Page: SpiderReview

//导入swiper图片的fileID
import { spiderDetailsImagesFileID } from '../../../defaultData.js'
//导入用到的Models
import { SpiderPreview } from '../../../models/spiderPreview.js'
//导入vant组件
import Toast from '../../../miniprogram_npm/vant-weapp/toast/toast';

let spiderPreview = new SpiderPreview()

Page({

  /**
   * 页面的初始数据
   * swiperImgUrls: swiper图片Urls
   * imgIndex: 当前的swiperImgIndex
   * indicatorDots: swiper的提示点
   */
  data: {
    swiperImgUrls: [],
    imgIndex: 0,
    indicatorDots: true,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //根据fileID数组长度生成等长的swiperImgUrls数组
    let length = spiderDetailsImagesFileID.length
    let swiperImgUrls = new Array(length)
    let imgIndex = this.data.imgIndex

    //加载第一个swiperImgUrls，生成第一张图片
    spiderPreview.loadImg(spiderDetailsImagesFileID[imgIndex])
      .then((res) => {
        swiperImgUrls[imgIndex] = res
        this.setData({
          swiperImgUrls: swiperImgUrls
        })
        //设置第一张的储存
        wx.setStorageSync(`swiperImgUrl${imgIndex}`, res)
      })
  },

  //滑动swiper处理函数
  changeSwiper: function (e) {
    let swiperImgUrls = this.data.swiperImgUrls
    let imgIndex = e.detail.current
    let imgUrlStor = wx.getStorageSync(`swiperImgUrl${imgIndex}`)

    //加载之前先查看储存，避免重复加载
    if (imgUrlStor != ''){
      let _imgUrlStor = `swiperImgUrls[${imgIndex}]`
      this.setData({
        [_imgUrlStor]: imgUrlStor
      })
    }
    else {
      //加载对应滑动到的swiperImgUrls，生成对应图片
      spiderPreview.loadImg(spiderDetailsImagesFileID[imgIndex])
        .then((res) => {
          swiperImgUrls[imgIndex] = res
          this.setData({
            swiperImgUrls: swiperImgUrls
          })
          wx.setStorageSync(`swiperImgUrl${imgIndex}`, res)
        })
    }
  },

  //改变swiper的状态点的处理函数
  changeIndicatorDots: function (e) {
    this.setData({
      indicatorDots: !this.data.indicatorDots
    })
  },

  //点击开始预习处理函数
  onPreview: function () {
    wx.navigateTo({
      url: '../spiderPreview/spiderPreview',
    })
  },

  //点击开始复习处理函数
  onReview: function () {
    wx.navigateTo({
      url: '../spiderReviewStart/spiderReviewStart',
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})