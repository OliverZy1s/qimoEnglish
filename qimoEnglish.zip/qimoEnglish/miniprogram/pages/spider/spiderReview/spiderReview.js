//复习页面
//展示一些单词卡片，对每个单词切换例句，切换单词和收藏

//导入一些必要Models
import { SpiderReview } from '../../../models/spiderReview.js'
import { Cloud } from '../../../models/cloud.js'

//导入vant组件
import Toast from '../../../miniprogram_npm/vant-weapp/toast/toast';

const app = getApp()
let spiderReview = new SpiderReview()
let cloud = new Cloud()

Page({

  /**
   * 页面的初始数据
   * reviewDataTotal: 当前页面的全部信息
   * reviewData: 当前页面的内容信息信息
   * reviewImgSrc: 当前页面的图片地址
   */
  data: {
    reviewDataTotal: null,
    reviewData: null,
    reviewImgSrc: '',
    btnText: 'Next',

    reviewContent: [
      {
        index: 0,
        chinese: '面很好吃',
        english: 'good noodles',
      },
      {
        index: 1,
        chinese: '面很好吃2',
        english: 'good noodles2',
      }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this._loadReviewFirst()
  },

  //加载第一页内容内部函数
  _loadReviewFirst: function () {
    let reviewData = this.data.reviewData
    let reviewImgSrc = ''

    //异步获取当前内容信息
    //res: {
    //  id, reviewImgFileID, reviewData
    //}
    spiderReview.getReviewFirst()
      .then((res) => {
        console.log("我成功加载到了第一个页面的全部信息：")
        console.log(res)
        //数据更新
        let reviewDataTotal = res
        let reviewData = res.reviewData
        this.setData({
          reviewDataTotal: reviewDataTotal,
          reviewData: reviewData,
        })
        //加载图片并对图片路径进行setData
        spiderReview.loadReviewImg(reviewDataTotal.reviewImgFileID)
          .then((res) => {
            reviewImgSrc = res
            this.setData({
              reviewImgSrc: reviewImgSrc
            })
            console.log("成功的加载并设置了当前图片路径")

            Toast.clear()
          })
      })
  },

  handleLike: function (e) {
    // 获取当前likeStatus状态，并在本地取反
    let id = this.data.reviewDataTotal.id
    let reviewData = this.data.reviewData

    let chinese = e.detail.chinese
    let likeStatus = e.detail.likeStatus
    let index = e.detail.index

    console.log("成功在page中获取点赞信息：")
    console.log(`id:${id},第${index}个中文:${chinese},现有状态为${likeStatus}`)

    //本地直接更新状态
    let _value = `reviewData[${index}].likeStatus`
    this.setData({
      [_value]: !likeStatus
    })
    console.log(`更改之后的reviewData数据为：`)
    console.log(reviewData)

    //如果现在的状态为false，则说明该操作为点赞
    if (likeStatus == false) {
      //点赞操作的内部处理函数，在数据库两处更新状态
      //1. userLibrary增添集合 2. 对应writingData全部字段
      console.log('onlike')
      let openid = app.globalData.openid
      let collectionName = 'review'
      let type = 'sentence'
      let name = chinese
      cloud.addLikeSenRe(openid, collectionName, type, name, id, reviewData)
    }
    //否则则为取消赞
    else {
      //取消点赞操作的内部处理函数，在数据库两处更新状态
      //1. userLibrary删除集合 2. 对应writingData全部字段
      console.log('offlike')
      let openid = app.globalData.openid
      let collectionName = 'review'
      let type = 'sentence'
      let name = chinese
      cloud.deleteLikeSenRe(openid, collectionName, type, name, id, reviewData)
    }
  },

  onNext: function (e) {
    //获取当下reviewData
    let id = this.data.reviewDataTotal.id
    let reviewData = this.data.reviewData

    //判断是否finish
    if (id == 3) {
      wx.navigateTo({
        url: '../../libraryStart/libraryStart',
      })
      console.log('已到文章的倒数最后一句话')
    }

    //判断是否finish  前一个
    if (id == 2) {
      this.setData({
        btnText: 'Finish'
      })
      console.log('已到文章的倒数第二句话，再进行点击就是最后一句')
    }

    //加载下一个句子的数据
    //没有设置储存，因为likeStatus的缘故，需要时刻更新
    Toast.loading({
      mask: true,
      message: '加载中...'
    });
    let id_new = id + 1
    console.log(id_new)
    spiderReview.getReviewNext(id_new)
      .then((res) => {
        console.log("我成功加载到下个页面的全部信息：")
        console.log(res)
        //数据更新
        let reviewDataTotal = res
        let reviewData = res.reviewData
        let reviewImgSrc = ''
        this.setData({
          reviewDataTotal: reviewDataTotal,
          reviewData: reviewData,
        })
        //加载图片并对图片路径进行setData
        spiderReview.loadReviewImg(reviewDataTotal.reviewImgFileID)
          .then((res) => {
            reviewImgSrc = res
            this.setData({
              reviewImgSrc: reviewImgSrc
            })
            console.log("成功的加载并设置了当前图片路径")
            Toast.clear()
          })
      })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    Toast.loading({
      mask: true,
      message: '加载中...'
    });
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})