//蜘蛛侠预习（词汇）页面
//*click < => AsynGet
//*click > => AsynGet
//*click like => AsynGet + AsynSend
//*click chnageEx => (wordCard -> this.Page)

//导入一些必要Models
import { SpiderPreview } from '../../../models/spiderPreview.js'
import { Cloud } from '../../../models/cloud.js'
//导入vant组件
import Toast from '../../../miniprogram_npm/vant-weapp/toast/toast';

const app = getApp()
let spiderPreview = new SpiderPreview()
let cloud = new Cloud()

Page({

  /**
   * 页面的初始数据
   * windowHeight: 屏幕高度
   * previewData: 当前页面的内容信息
   */
  data: {
    windowHeight: 0,
    previewData: {},
    bgdImgTempSrc: '',
    wordCardImgSrc: '',
    likeStatus: false,
    likeSrc: './images/star_white_off@2x.png',
    dislikeSrc: './images/star_white_on@2x.png',
    proMessage: {
      currentIndex: 1,
      totalIndex: 6
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //！！！因为部分机型下底角圆弧问题，可能无法完全覆盖
    //！！！因此暂时做出粗略适配
    //为背景图片全覆盖而设置全屏高度
    let windowHeight = wx.getSystemInfoSync().windowHeight * 2 + 60
    this.setData({
      windowHeight: windowHeight
    })

    //加载第一页内容
    this._loadPreviewFirst()
  },

  //加载第一页内容内部函数
  _loadPreviewFirst: function () {
    let previewData = this.data.previewData
    let bgdImgTempSrc = ''
    let wordCardImgSrc = ''

    Toast.loading({
      mask: true,
      message: '加载中...'
    });
    
    //异步获取当前内容信息
    //previewData: {
    //  id, name, type, bgdImgFileID, wordCardImgFileID
    //  examples, likeStatus
    //}
    spiderPreview.getPreviewFirst()
      .then((res) => {
        let previewData = res
        this.setData({
          previewData: previewData,
        })
        //加载背景图片路径
        //并对两张图片路径进行setData
        spiderPreview.loadPreviewImg(previewData.bgdImgFileID)
          .then((res) => {
            bgdImgTempSrc = res
            this.setData({
              bgdImgTempSrc: bgdImgTempSrc
            })

            spiderPreview.loadPreviewImg(previewData.wordCardImgFileID)
              .then((res) => {
                wordCardImgSrc = res
                this.setData({
                  wordCardImgSrc: wordCardImgSrc
                })
                Toast.clear()
              })
          })
      })
  },

  //点击<事件处理函数
  onPrevious: function () {
    let id = this.data.previewData.id
    if (this._isFirst(id)){
      Toast('第一张~');
    }
    else {
      this._loadPreviewPrevious()
    }
  },

  //如果为第一张
  _isFirst: function (id) {
    return id == 1 ? true : false
  },

  //加载前一页内容信息内部处理函数
  _loadPreviewPrevious: function () {
    let previewData = this.data.previewData
    let id = previewData.id
    let bgdImgTempSrc = ''
    let wordCardImgSrc = ''

    //先从储存中查找是否已经加载图片
    if (wx.getStorageSync(`bgdImg${id - 1}`) != '') {
      let previewData = wx.getStorageSync(`previewData${id - 1}`)
      let bgdImgTempSrc = wx.getStorageSync(`bgdImg${id - 1}`)
      let wordCardImgSrc = wx.getStorageSync(`wordCardImg${id - 1}`)

      //同时，若从储存中取得内容信息，是有可能取不到当前likeStatus的
      //因此，仍需要单独取一次likeStatus
      //res: likeStatus
      spiderPreview.getPreLikeStatus(id - 1)
        .then((res) => {
          let likeStatus = res
          //这里是为了同步更新，防止likeStatus更新过慢体验不好
          this.setData({
            bgdImgTempSrc: bgdImgTempSrc,
            wordCardImgSrc: wordCardImgSrc,
            previewData: previewData
          })
          this.setData({
            'previewData.likeStatus': likeStatus
          })
          //更新proMessage
          let proMessage = this.data.proMessage
          proMessage.currentIndex = proMessage.currentIndex - 1
          this.setData({
            proMessage: proMessage
          })
        })
    }
    //否则，开始从云端加载
    else {
      Toast.loading({
        mask: true,
        message: '加载中...'
      });
      //异步获取前一页内容信息
      //res: 前一页的previewData
      spiderPreview.getPreviewPrevious(id)
        .then((res) => {
          let previewData = res
          //设置缓存
          wx.setStorageSync(`previewData${id - 1}`, previewData)
          this.setData({
            previewData: previewData,
          })
          //加载背景图片路径
          spiderPreview.loadPreviewImg(previewData.bgdImgFileID)
            .then((res) => {
              //设置缓存
              bgdImgTempSrc = res
              wx.setStorageSync(`bgdImg${id - 1}`, bgdImgTempSrc)
              this.setData({
                bgdImgTempSrc: bgdImgTempSrc
              })
              //加载单词卡片图片路径
              spiderPreview.loadPreviewImg(previewData.wordCardImgFileID)
                .then((res) => {
                  wordCardImgSrc = res
                  wx.setStorageSync(`wordCardImg${id - 1}`, wordCardImgSrc)
                  this.setData({
                    wordCardImgSrc: wordCardImgSrc
                  })
                  //更新proMessage
                  let proMessage = this.data.proMessage
                  proMessage.currentIndex = proMessage.currentIndex - 1
                  this.setData({
                    proMessage: proMessage
                  })
                  Toast.clear()
                })
            })
        })
    }
  },

  //点击>事件处理函数
  onNext: function () {
    let id = this.data.previewData.id
    if (this._isLast(id)) {
      Toast('最后一张~');
    }
    else {
      this._loadPreviewNext()
    }
  },

  //如果为最后一张
  _isLast: function (id) {
    return id == 6 ? true : false
  },

  //加载后一页内容信息内部处理函数
  _loadPreviewNext: function () {
    let previewData = this.data.previewData
    let id = previewData.id
    let bgdImgTempSrc = ''
    let wordCardImgSrc = ''

    //先从储存中查找是否已经加载图片
    if (wx.getStorageSync(`bgdImg${id + 1}`) != '') {
      let previewData = wx.getStorageSync(`previewData${id + 1}`)
      let bgdImgTempSrc = wx.getStorageSync(`bgdImg${id + 1}`)
      let wordCardImgSrc = wx.getStorageSync(`wordCardImg${id + 1}`)
      //同时，若从储存中取得内容信息，是有可能取不到当前likeStatus的
      //因此，仍需要单独取一次likeStatus
      //res: likeStatus
      spiderPreview.getPreLikeStatus(id + 1)
        .then((res) => {
          let likeStatus = res
          //这里是为了同步更新，防止likeStatus更新过慢体验不好
          this.setData({
            bgdImgTempSrc: bgdImgTempSrc,
            wordCardImgSrc: wordCardImgSrc,
            previewData: previewData
          })
          this.setData({
            'previewData.likeStatus': likeStatus
          })
          //更新proMessage
          let proMessage = this.data.proMessage
          proMessage.currentIndex = proMessage.currentIndex + 1
          this.setData({
            proMessage: proMessage
          })
        })
    }
    //否则，开始从云端加载
    else {
      Toast.loading({
        mask: true,
        message: '加载中...'
      });
      //异步获取后一页内容信息
      //res: 后一页的previewData
      spiderPreview.getPreviewNext(id)
        .then((res) => {
          let previewData = res
          //设置缓存
          wx.setStorageSync(`previewData${id + 1}`, previewData)
          this.setData({
            previewData: previewData,
          })
          //加载背景图片路径
          spiderPreview.loadPreviewImg(previewData.bgdImgFileID)
            .then((res) => {
              //设置缓存
              bgdImgTempSrc = res
              wx.setStorageSync(`bgdImg${id + 1}`, bgdImgTempSrc)
              this.setData({
                bgdImgTempSrc: bgdImgTempSrc
              })
              //加载单词卡片图片路径
              spiderPreview.loadPreviewImg(previewData.wordCardImgFileID)
                .then((res) => {
                  wordCardImgSrc = res
                  wx.setStorageSync(`wordCardImg${id + 1}`, wordCardImgSrc)
                  this.setData({
                    wordCardImgSrc: wordCardImgSrc
                  })
                  //更新proMessage
                  let proMessage = this.data.proMessage
                  proMessage.currentIndex = proMessage.currentIndex + 1
                  this.setData({
                    proMessage: proMessage
                  })
                  Toast.clear()
                })
            })
        })
    }
  },
  
  //点赞操作的处理函数
  handleLike: function () {
    //获取当前likeStatus状态，并在本地取反
    let previewData = this.data.previewData
    previewData.likeStatus = !previewData.likeStatus
    //本地直接更新状态
    this.setData({
      previewData: previewData
    })
    //如果更新之后的状态为true，则说明该操作为点赞
    if (previewData.likeStatus == true) {
      console.log('onlike')
      this._onLike()
    }
    //否则则为取消赞
    else {
      console.log('offlike')
      this._offLike()
    }
  },

  //点赞操作的内部处理函数，在数据库两处更新状态
  //1. userLibrary增添集合 2. 对应previewData中的likeStatus字段
  _onLike: function () {
    let openid = app.globalData.openid
    let collectionName = 'preview'
    let type = this.data.previewData.type
    let name = this.data.previewData.name
    cloud.addLike(openid, collectionName, type, name)
  },

  //取消点赞操作的内部处理函数，在数据库两处更新状态
  //1. userLibrary删除集合 2. 对应previewData中的likeStatus字段
  _offLike: function () {
    let openid = app.globalData.openid
    let collectionName = 'preview'
    let type = this.data.previewData.type
    let name = this.data.previewData.name
    cloud.deleteLike(openid, collectionName, type, name)
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})