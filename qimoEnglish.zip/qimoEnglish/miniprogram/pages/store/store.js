//商店页面
//*click SpiderImg => Page: SpiderDetails
//*click WritingImg => Page: WritingDetails
//*click LibraryIcon => Page: LibraryStart

//导入商品图片的FileID
import { appImagesFileID } from '../../defaultData.js'
//导入会用到的Models
import { StoreModel } from '../../models/store.js'
import { Cloud } from '../../models/cloud.js'
//导入vant组件
import Toast from '../../miniprogram_npm/vant-weapp/toast/toast';

const app = getApp()
let cloud = new Cloud()
let storeModel = new StoreModel()

Page({

  /**
   * 页面的初始数据:
   * spiderImgSrc: 第一个商品，蜘蛛侠的图片路径，
   * writingImgSrc: 第二个商品，托福写作的图片路径
   */
  data: {
    spiderImgSrc: '',
    writingImgSrc: '',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //在最开始就获取用户openid并存入globalData
    cloud.onGetOpenid(app)

    //加载蜘蛛侠图片并设置
    storeModel.loadAppImg(appImagesFileID[0])
    .then((res)=>{
      this.setData({
        spiderImgSrc: res
      })
    })

    //加载写作图片并设置
    storeModel.loadAppImg(appImagesFileID[1])
      .then((res) => {
        this.setData({
          writingImgSrc: res
        })
      })

  },

  //点击蜘蛛侠图片处理函数
  onSpider: function() {
    wx.navigateTo({
      url: '../spider/spiderDetails/spiderDetails',
    })
  },

  //点击写作图片处理函数
  onWriting: function() {
    wx.navigateTo({
      url: '../writing/writingDetails/writingDetails',
    })
  },

  //点击知识库图标处理函数
  onLibrary: function() {
    wx.navigateTo({
      url: '../library/libraryStart/libraryStart',
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})