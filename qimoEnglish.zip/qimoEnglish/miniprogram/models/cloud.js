class Cloud{
  onGetOpenid(app){
    return new Promise((resolve, reject)=>{
      // 调用云函数
      wx.cloud.callFunction({
        name: 'login',
        data: {},
        success: res => {
          console.log('[云函数] [login] user openid: ', res.result.openid)
          app.globalData.openid = res.result.openid
        },
        fail: err => {
          console.error('[云函数] [login] 调用失败', err)
        }
      })
    })
  }

  addLike(openid, collectionName, type, name){
    const db = wx.cloud.database()
    //向知识库添加一条记录
    let promiseAdd = new Promise((resolve, reject)=>{
      db.collection('userLibrary').add({
        data: {
          type: type,
          name: name
        },
        success: res => {
          resolve()
          wx.showToast({
            title: '收藏成功',
          })
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '新增记录失败'
          })
        }
      })
    })

    //更改对应collection里对应doc的likeStatus
    let promiseGet = new Promise((resolve, reject)=>{
      db.collection(collectionName).where({
        _openid: openid,
        name: name
      })
      .get({
        success: res => {
          resolve(res)

        },
        fail: err => {

        }
      })
    })
    promiseGet.then((res)=>{
      console.log(res)
      let docData = res.data[0]
      let docId = docData._id
      db.collection(collectionName).doc(docId).update({
        data:{
          likeStatus: true
        }
      })
    })
  }

  deleteLike(openid, collectionName, type, name) {
    const db = wx.cloud.database()
    //向知识库删除一条记录
    //注意！因为remove方法不能直接删除集合，所以必须先要获取
    //对应的docId再去删除单个元素
    let promiseGetUser = new Promise((resolve, reject) => {
      db.collection('userLibrary').where({
        _openid: openid,
        name: name,
        type: type
      })
        .get({
          success: res => {
            let data = res.data[0]
            resolve(data._id)
          },
          fail: err => {

          }
        })
    })
    promiseGetUser.then((res) => {
      console.log(res)
      let docId = res
      db.collection('userLibrary').doc(docId).remove({
        data: {
          _openid: openid,
          name: name,
          type: type
        }
      })
    })

    //更改对应collection里对应doc的likeStatus
    let promiseGet = new Promise((resolve, reject) => {
      db.collection(collectionName).where({
        _openid: openid,
        name: name
      })
        .get({
          success: res => {
            resolve(res)

          },
          fail: err => {

          }
        })
    })
    promiseGet.then((res) => {
      console.log(res)
      let docData = res.data[0]
      let docId = docData._id
      db.collection(collectionName).doc(docId).update({
        data: {
          likeStatus: false
        }
      })
    })
  }

  addLikeSen(openid, collectionName, type, name, topicIndex, writingDataStr, writingData) {
    const db = wx.cloud.database()
    //向知识库添加一条记录
    let promiseAdd = new Promise((resolve, reject) => {
      db.collection('userLibrary').add({
        data: {
          type: type,
          name: name
        },
        success: res => {
          resolve()
          wx.showToast({
            title: '在知识库中收藏成功',
          })
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '在知识库中新增记录失败'
          })
        }
      })
    })

    //更改对应collection里对应doc的likeStatus
    let promiseGet = new Promise((resolve, reject) => {
      db.collection(collectionName).where({
        _openid: openid,
        topicIndex: topicIndex
      })
        .get({
          success: res => {
            let writingDataTotal = res.data[0]
            resolve(writingDataTotal)
            console.log('成功获取到对应对应topic的writingDataTotal：')
            console.log(writingDataTotal)
          },
          fail: err => {

          }
        })
    })
    promiseGet.then((res) => {
      let docData = res
      let docId = docData._id
      console.log('开始向对应id的doc更新数据')
      console.log(writingDataStr)
      console.log(writingData)
      db.collection(collectionName).doc(docId).update({
        data: {
          [writingDataStr]: writingData
        }
    })
    })
  }

  deleteLikeSen(openid, collectionName, type, name, topicIndex, writingDataStr, writingData) {
    const db = wx.cloud.database()
    //向知识库删除一条记录
    //注意！因为remove方法不能直接删除集合，所以必须先要获取
    //对应的docId再去删除单个元素
    let promiseGetUser = new Promise((resolve, reject) => {
      db.collection('userLibrary').where({
        _openid: openid,
        name: name,
        type: type
      })
        .get({
          success: res => {
            let data = res.data[0]
            resolve(data._id)
          },
          fail: err => {

          }
        })
    })
    promiseGetUser.then((res) => {
      console.log(res)
      let docId = res
      db.collection('userLibrary').doc(docId).remove({
        data: {
          _openid: openid,
          name: name,
          type: type
        }
      })
    })


    //更改对应collection里对应doc的likeStatus
    let promiseGet = new Promise((resolve, reject) => {
      db.collection(collectionName).where({
        _openid: openid,
        topicIndex: topicIndex
      })
        .get({
          success: res => {
            let writingDataTotal = res.data[0]
            resolve(writingDataTotal)
            console.log('成功获取到对应对应topic的writingDataTotal：')
            console.log(writingDataTotal)
          },
          fail: err => {

          }
        })
    })
    promiseGet.then((res) => {
      let docData = res
      let docId = docData._id
      console.log('开始向对应id的doc更新数据')
      console.log(writingDataStr)
      console.log(writingData)
      db.collection(collectionName).doc(docId).update({
        data: {
          [writingDataStr]: writingData
        }
      })
    })
  }

  addLikeSenRe(openid, collectionName, type, name, id, reviewData) {
    const db = wx.cloud.database()
    //向知识库添加一条记录
    let promiseAdd = new Promise((resolve, reject) => {
      db.collection('userLibrary').add({
        data: {
          type: type,
          name: name
        },
        success: res => {
          resolve()
          wx.showToast({
            title: '在知识库中收藏成功',
          })
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '在知识库中新增记录失败'
          })
        }
      })
    })

    //更改对应collection里对应doc的likeStatus
    let promiseGet = new Promise((resolve, reject) => {
      db.collection(collectionName).where({
        _openid: openid,
        id: id
      })
        .get({
          success: res => {
            let reviewDataTotal = res.data[0]
            resolve(reviewDataTotal)
            console.log('成功获取到对应对应id的reviewDataTotal：')
            console.log(reviewDataTotal)
          },
          fail: err => {

          }
        })
    })
    promiseGet.then((res) => {
      let docData = res
      let docId = docData._id
      console.log('开始向对应id的doc更新数据')
      console.log(reviewData)
      db.collection(collectionName).doc(docId).update({
        data: {
          reviewData: reviewData
        }
      })
    })
  }

  deleteLikeSenRe(openid, collectionName, type, name, id, reviewData) {
    const db = wx.cloud.database()
    //向知识库删除一条记录
    //注意！因为remove方法不能直接删除集合，所以必须先要获取
    //对应的docId再去删除单个元素
    let promiseGetUser = new Promise((resolve, reject) => {
      db.collection('userLibrary').where({
        _openid: openid,
        name: name,
        type: type
      })
        .get({
          success: res => {
            let data = res.data[0]
            resolve(data._id)
          },
          fail: err => {

          }
        })
    })
    promiseGetUser.then((res) => {
      console.log(res)
      let docId = res
      db.collection('userLibrary').doc(docId).remove({
        data: {
          _openid: openid,
          name: name,
          type: type
        }
      })
    })


    //更改对应collection里对应doc的likeStatus
    let promiseGet = new Promise((resolve, reject) => {
      db.collection(collectionName).where({
        _openid: openid,
        id: id
      })
        .get({
          success: res => {
            let reviewDataTotal = res.data[0]
            resolve(reviewDataTotal)
            console.log('成功获取到对应对应id的reviewDataTotal：')
            console.log(reviewDataTotal)
          },
          fail: err => {

          }
        })
    })
    promiseGet.then((res) => {
      let docData = res
      let docId = docData._id
      console.log('开始向对应id的doc更新数据')
      console.log(reviewData)
      db.collection(collectionName).doc(docId).update({
        data: {
          reviewData: reviewData
        }
      })
    })
  }
}

export { Cloud }