class Library {
  getLibraryAll() {
    return new Promise((resolve, reject) => {
      const db = wx.cloud.database()
      db.collection('userLibrary')
      .get({
        success: res => {
          resolve(res.data)
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      })
    })
  }

  getWordDetails(name) {
    return new Promise((resolve, reject) => {
      const db = wx.cloud.database()
      db.collection('wordLibrary').where({
        name: name
      }).get({
        success: res => {
          let wordData = res.data[0]
          resolve(wordData)
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      })
    })
  }

  getSenDetails(name) {
    return new Promise((resolve, reject) => {
      const db = wx.cloud.database()
      db.collection('senLibrary').where({
        name: name
      }).get({
        success: res => {
          let senData = res.data[0]
          resolve(senData)
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      })
    })
  }
}

export { Library }