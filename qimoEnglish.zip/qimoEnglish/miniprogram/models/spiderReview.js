class SpiderReview {
  getReviewFirst(){
    return new Promise((resolve, reject) => {
      const db = wx.cloud.database()
      db.collection('review').where({
        id: 1
      }).get({
        success: res => {
          let reviewDataTotal = res.data[0]
          resolve(reviewDataTotal)
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      })
    })
  }

  getReviewNext(id) {
    return new Promise((resolve, reject) => {
      const db = wx.cloud.database()
      db.collection('review').where({
        id: id
      }).get({
        success: res => {
          let reviewDataTotal = res.data[0]
          resolve(reviewDataTotal)
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      })
    })
  }

  loadReviewImg(fileID) {
    return new Promise((resolve, reject) => {
      wx.cloud.downloadFile({
        fileID: fileID,
        success: res => {
          resolve(res.tempFilePath)
        },
        fail: console.error
      })
    })
  }

  
}

export { SpiderReview }