class Writing {
  getWritingFirst(topicIndex) {
    return new Promise((resolve, reject) => {
      const db = wx.cloud.database()
      db.collection('writing').where({
        topicIndex: topicIndex
      }).get({
        success: res => {
          let writingData = res.data[0]
          resolve(writingData)
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      })
    })
  }

  getWritingNext(id) {
    return new Promise((resolve, reject) => {
      const db = wx.cloud.database()
      db.collection('writing').where({
        id: id+1
      }).get({
        success: res => {
          resolve(res)
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      })
    })
  }
}

export { Writing }