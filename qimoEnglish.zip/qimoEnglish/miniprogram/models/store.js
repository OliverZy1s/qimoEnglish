class StoreModel {

  //传递已知的fileID从云端储存中下载图片
  loadAppImg(fileID){
    return new Promise((resolve, reject)=>{
      wx.cloud.downloadFile({
        fileID: fileID, 
        success: res => {
          resolve(res.tempFilePath)
        },
        fail: console.error
      })
    })
  }
}

export { StoreModel } 