class SpiderPreview {
  loadImg(fileID) {
    return new Promise((resolve, reject)=>{
      let imgUrl = ''
      wx.cloud.downloadFile({
        fileID: fileID,
        success: res => {
          resolve(res.tempFilePath)
        },
        fail: console.error
      })
      
    })
  }

  loadPreviewImg(fileID) {
    return new Promise((resolve, reject) => {
      wx.cloud.downloadFile({
        fileID: fileID,
        success: res => {
          resolve(res.tempFilePath)
        },
        fail: console.error
      })
    })
  }

  getPreviewFirst(){
    return new Promise((resolve, reject)=>{
      const db = wx.cloud.database()
      db.collection('preview').where({
        id: 1
      }).get({
        success: res => {
          let previewData = res.data[0]
          resolve(previewData)
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      })
    })
  }

  getPreLikeStatus(id) {
    return new Promise((resolve, reject)=>{
      const db = wx.cloud.database()
      db.collection('preview')
      .where({
        id: id
      })
      .get({
        success: res => {
          let previewData = res.data[0]
          resolve(previewData.likeStatus)
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      })
    })
  }

  // getPreviewId(id) {
  //   return new Promise((resolve, reject) => {
  //     const db = wx.cloud.database()
  //     db.collection('preview').where({
  //       id: id
  //     }).get({
  //       success: res => {
  //         resolve(res)
  //       },
  //       fail: err => {
  //         wx.showToast({
  //           icon: 'none',
  //           title: '查询记录失败'
  //         })
  //         console.error('[数据库] [查询记录] 失败：', err)
  //       }
  //     })
  //   })
  // }

  getPreviewPrevious(id) {
    return new Promise((resolve, reject) => {
      const db = wx.cloud.database()
      let _id = id - 1
      db.collection('preview').where({
        id: _id
      }).get({
        success: res => {
          let reviewData = res.data[0]
          resolve(reviewData)
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      })
    })
  }

  getPreviewNext(id) {
    return new Promise((resolve, reject) => {
      const db = wx.cloud.database()
      let _id = id + 1
      
      db.collection('preview').where({
        id: _id
      }).get({
        success: res => {
          let reviewData = res.data[0]
          resolve(reviewData)
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          console.error('[数据库] [查询记录] 失败：', err)
        }
      })
    })
  }

  // addLike()
    
}

export { SpiderPreview }