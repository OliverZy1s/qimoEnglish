const appImagesFileID = [
  "cloud://huangjing1-76f1c3.6875-huangjing1-76f1c3/app-images/appSpiderImg.png",       "cloud://huangjing1-76f1c3.6875-huangjing1-76f1c3/app-images/appWritingImg.png"
]

const spiderDetailsImagesFileID = [
"cloud://huangjing1-76f1c3.6875-huangjing1-76f1c3/spiderDetails-images/detailsFirst.jpg","cloud://huangjing1-76f1c3.6875-huangjing1-76f1c3/spiderDetails-images/detailsSecond.jpg",
"cloud://huangjing1-76f1c3.6875-huangjing1-76f1c3/spiderDetails-images/detailsThird.jpg"
]

const writingTopic = ["Young people today are more likely to help others than young people in the past. What do you think of this statements?", "Old people today are more likely to help others than old people in the past. What do you think of this statements"]

const writingChinese = ["世界正在飞速发展，相应地，人们一代一代地在进步。现在，年轻人比他们的年长的一代拥有更广阔的眼界，更丰富的知识和更大的野心。"]

const writingEnglish = ["The world is rapidly developing, corres-pondingly, people are progressing gene-ration after generation. Currently, the young people have broader horizen, richer knowledge and greater ambition than the elder generation had."]

export { appImagesFileID, writingTopic, spiderDetailsImagesFileID, writingChinese, writingEnglish }